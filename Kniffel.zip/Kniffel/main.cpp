#include <iostream>
#include "header_files/spielFeld.h"
#include "header_files/spieler.h"

using namespace std;

int main() {
	unsigned int spielerAnzahl;

	cout << "Kniffel-Spiel fängt an:\n" << endl;
	cout << "Wieviel Spieler spielen mit? " << endl;
	cin >> spielerAnzahl;

	SpielFeld spielFeld(spielerAnzahl);
	vector<Spieler> spielerListe = spielFeld.spielerKreieren();

	spielFeld.spielerAnzeigen(spielerListe);
}
